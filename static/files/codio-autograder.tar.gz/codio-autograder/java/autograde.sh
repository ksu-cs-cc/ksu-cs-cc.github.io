#!/bin/bash

# Save Student Work
DATE=`date "+%Y%m%d_%H%M%S_%N"`
mkdir -p $extract_path/$DATE

KEY=`cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1`

# Make unique key file for student
if [ ! -f $extract_path/key.txt ]; then
  echo "${DATE}_${KEY}" > $extract_path/key.txt
fi

echo "Student Key: $(<$extract_path/key.txt)"

# Compile Source
cd $source_path
rm -f *.class
javac $java_source_files

# Compile Tests
cd $test_path
rm -f *.class
javac -cp $source_path:$autograde_path/junit.jar:$autograde_path/hamcrest.jar:$autograde_path/CodioAutograder.jar:$test_path $java_test_classes

# Change to directory of script
cd $DIR

# Run Tests
java -cp $autograde_path/CodioAutograder.jar:$autograde_path/commons-cli-1.4.jar:$autograde_path/commons-lang3-3.9.jar:$source_path:$test_path CodioAutograder $flags -f $output_path -o $other_weight -t $test_weights

# Copy student work files from source
rsync -am $source_path/ $extract_path/$DATE --exclude /tests --exclude /input.txt --exclude __pycache__ --exclude '*.class' --exclude '*.pyc'