#!/bin/bash

# Compile Source
cd $source_path
rm *.class
javac $java_source_files

# Compile Tests
cd $test_path
rm *.class
javac -cp $source_path:$autograde_path/junit.jar:$autograde_path/hamcrest.jar:$autograde_path/CodioAutograder.jar $test_path $java_test_classes

# Run Tests
java -cp $autograde_path/CodioAutograder.jar:$autograde_path/commons-cli-1.4.jar:$source_path:$test_path CodioAutograder $flags -f $output_path -o $other_weight -t $test_weights
