import sys
import datetime

class CodioLogger():

    def __init__(self, outputfile, logfile):

        try:
            self.output = open(outputfile, 'w')
            self.logger = open(logfile, 'w')
        except Exception as ex:
            print("Error parsing test classes and weights!", file=sys.stderr)
            print(ex, file=sys.stderr)

            if self.output:
                self.output.close()
            if self.logger:
                self.logger.close()

            sys.exit(1)

    def close(self):
        self.output.write("</body>\n")
        self.output.write("</html>\n")
        self.output.close()
        self.logger.close()
        self.output = None
        self.logger = None

    def printHeaders(self):
        date = datetime.datetime.now()

        self.output.write("<html>\n")
        self.output.write("<body>\n")
        self.output.write("<h1>Autograder Feedback</h1>\n")
        self.output.write("<p><i>Timestamp: " + str(date) + "</i></p>\n")

        self.logger.write("Autograder Log\n")
        self.logger.write("Timestamp: " + str(date) + "\n")

    def log(self, out):
        self.logger.write(str(out) + "\n")

    def printH2(self, out):
        self.output.write("<h2>" + str(out) + "</h2>\n")

    def printI(self, out):
        self.output.write("<p><i>" + str(out) + "</i></p>\n")

    def printP(self, out):
        self.output.write("<p>" + str(out) + "</p>\n")

    def printClassHeader(self, name):
        self.output.write("<hr>\n")
        self.printH2("Test: {}\n".format(name))

        self.log("==========================================")
        self.log("Test Class: " + name + " ... ")

    def printCustomResults(self, results, score, weight):
        self.output.write("<p><b>Total Score:</b> {:.1%}</p>\n".format(score))
        self.output.write("<p><b>Weight:</b> {}%</p>\n".format(weight))

        self.log("Score: {}".format(score))

        for result in results:
            self.output.write("<hr>\n");
            self.output.write(
                "<h3>Type: {} | Input: {} | Output: {}</h3>\n".format(result['testType'], result['inputFile'], result['outputFile']))
            self.output.write("<b>Score:</b> {:.1%}".format(result['score']))
            if result['score'] < 1.0:
                self.output.write("<p><b>Your Output:</b></p>\n")
                self.output.write("<pre><code>")
                self.output.write(str(result['programOutput']))
                self.output.write("\n")
                self.output.write("</code></pre>\n")
                self.output.write("<p><b>Expected Output:</b></p>\n")
                self.output.write("<pre><code>")
                self.output.write(str(result['expectedOutput']))
                self.output.write("\n")
                self.output.write("</code></pre>\n")
                if result['message']:
                    self.output.write("<p><b>Helpful Hint:</b> {}</p>\n".format(result['message']))


    def printPyUnitResults(self, result, score, weight):
        successes = result.testsRun - len(result.failures) - len(result.errors)

        fails = len(result.failures)
        failPercent = fails / result.testsRun

        self.output.write("<p><b>Total Score:</b> {:.1%}</p>\n".format(score))
        self.output.write("<p><b>Weight:</b> {}%</p>\n".format(weight))

        self.log("Score: {}".format(score))

        self.output.write("<h3>Statistics</h3>\n")
        self.output.write("<ul>\n")
        self.output.write("<li><b>Total Tests</b>: {}</li>\n".format(result.testsRun))
        self.output.write("<li><b>Passed</b>: {} ({:.1%})</li>\n".format(successes, score))
        self.output.write("<li><b>Failed</b>: {} ({:.1%})</li>\n".format(fails, failPercent))
        self.output.write("<li><b>Skipped</b>: {}</li>\n".format(len(result.skipped)))
        self.output.write("<li><b>Errors</b>: {}</li>\n".format(len(result.errors)))
        self.output.write("</ul>\n")

        if result.wasSuccessful():
            self.output.write("<h4>All Tests Passed!</h4>\n")
        else:
            self.output.write("<h4>Failed Tests</h4>\n")
            self.output.write("<p><i>Consult the log file for detailed output</i></p>\n")
            self.output.write("<ul>\n")
            for fail, message in result.failures:
                message = message.splitlines()[3]
                self.output.write("<li>{} - {}</li>\n".format(fail._testMethodName, message))
            self.output.write("</ul>\n")

    def printSummary(self, tests, finalScore, scale):
        self.output.write("<hr>\n")
        self.printH2("Summary")

        self.log("==========================================")
        self.log("***SUMMARY***")

        for test in tests:
            self.output.write("<p><b>{}:</b> {:.1%} * {} = {:.1%}</p>\n".format(test['classname'], test['score'], test['weight'], (test['score'] * test['weight'] / 100)))
            self.log("{}: {} * {}% = {}".format(test['classname'], test['score'], test['weight'], (test['score'] * test['weight'] / 100)))

        if not scale == 1.0:
            self.output.write("<p><i>Scores will be scaled by {} to make the total weight 100.</i></p>\n".format(scale))
            self.log("Scores are scaled by {}".format(scale))

        self.output.write("<h3>Final Score: {}%</h3>\n".format(finalScore))
        self.log("++++++++++++++++++++")
        self.log("Final Score: {}%".format(finalScore))