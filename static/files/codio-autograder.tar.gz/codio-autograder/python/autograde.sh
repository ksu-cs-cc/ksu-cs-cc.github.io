#!/bin/bash

# Save Student Work
DATE=`date "+%Y%m%d_%H%M%S_%N"`
mkdir -p $extract_path/$DATE

KEY=`cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1`

# Make unique key file for student
if [ ! -f $extract_path/key.txt ]; then
  echo "${DATE}_${KEY}" > $extract_path/key.txt
fi

export PYTHONPATH="$source_path/:$test_path/:$PYTHONPATH"

# Change to directory of script
cd $DIR

python3 $autograde_path/CodioAutograder.py $flags -o $other_weight $output_path $test_weights

# Copy student work files from source
rsync -am $source_path/ $extract_path/$DATE --exclude /tests --exclude /input.txt --exclude __pycache__ --exclude '*.class' --exclude '*.pyc'

echo "Student Key: $(<$extract_path/key.txt)"