#!/bin/bash

export PYTHONPATH="$source_path/:$test_path/:$PYTHONPATH"

python3 $autograde_path/CodioAutograder.py -u -o $other_weight $output_path $test_weights