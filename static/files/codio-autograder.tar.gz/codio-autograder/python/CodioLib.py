import json
import os
import requests
import sys

class CodioLib:

    def getOtherScore(self, logger):

        otherScoresJSON = os.environ.get('CODIO_AUTOGRADE_ENV')

        # Log JSON in logger output
        logger.log("==========================================")
        logger.log("Autograde JSON Output:")
        logger.log(otherScoresJSON)

        # Print Log Header
        logger.output.write("<hr>\n")
        logger.printH2("Other Assessments")

        if not otherScoresJSON or otherScoresJSON == None:
            logger.printI("There were no other assessments in this module")
            logger.log("==========================================")

            return 0

        else:
            otherScoresObject = json.loads(otherScoresJSON)

            score = 0.0

            try:
                pointsEarned = otherScoresObject['assessments']['stats']['points']
                pointsTotal = otherScoresObject['assessments']['stats']['totalPoints']
                score = pointsEarned / pointsTotal

                logger.printP("You scored {} / {} ( {:.1%} ) on the other assessments in this module".format(pointsEarned, pointsTotal, score))
                logger.log("Score: {} / {} ( {:.1%} )".format(pointsEarned, pointsTotal, score))

            except Exception as ex:
                logger.printI("Unable to parse other assessments!<br>Consult log file for detailed output.")
                logger.log("Unable to parse other assessments!")
                logger.log(ex)

            logger.log("==========================================")

            return score

    def sendScore(self, finalScore, logger):
        # Get submission URL from environment
        submitURL = os.environ.get('CODIO_AUTOGRADE_URL')

        if not submitURL or submitURL == None:
            logger.log("Autograde URL is null - assume testing")
            logger.printI("Score not submitted! Consult the log file for details.")
            return True

        else:
            sumbitURL = "{0}&grade={1}".format(submitURL, finalScore)

            logger.log("Autograde URL: " + submitURL);
            logger.log("Submitting Final Score: {}".format(finalScore))

            try:
                s = requests.Session()
                s.mount('https://', requests.adapters.HTTPAdapter(max_retries=3))
                r = s.get(submitURL)
                parsed = json.loads(r.content.decode("utf-8"))

                # If return code is not 1
                if parsed['code'] != 1:
                    logger.log("Error! Grade submit failed!")
                    logger.log("==========================================")
                    logger.log(str(parsed))
                    logger.printI("Score submission failed! Consult the log file for details.")
                    return False

            except Exception as ex:
                print("Grade Submission Failed!", file=sys.stderr)
                logger.log("Error! Unable to submit grade!")
                logger.log(ex)
                logger.printI("Score submission failed! Consult the log file for details.")
                return False

            logger.printI("Score submitted successfully!")
            return True


    def partialPoints(self, finalScore, logger):
        # Get submission URL from environment
        submitURL = os.environ.get('CODIO_PARTIAL_POINTS_URL')

        if not submitURL or submitURL == None:
            logger.log("Partial Points URL is null - assume testing")
            logger.printI("Score not submitted! Consult the log file for details.")
            return True

        else:
            submitURL = "{0}&points={1}".format(submitURL, finalScore)

            logger.log("Partial Points URL: " + submitURL)
            logger.log("Submitting Final Score: {}".format(finalScore))

            try:
                s = requests.Session()
                s.mount('https://', requests.adapters.HTTPAdapter(max_retries=3))
                r = s.get(submitURL)
                parsed = json.loads(r.content.decode("utf-8"))

                # If return code is not 1
                if parsed['code'] != 1:
                    logger.log("Error! Grade submit failed!")
                    logger.log("==========================================")
                    logger.log(str(parsed))
                    logger.printI("Score submission failed! Consult the log file for details.")
                    return False

            except Exception as ex:
                print("Grade Submission Failed!", file=sys.stderr)
                logger.log("Error! Unable to submit grade!")
                logger.log(ex)
                logger.printI("Score submission failed! Consult the log file for details.")
                return False

            logger.printI("Score submitted successfully!")
            return True