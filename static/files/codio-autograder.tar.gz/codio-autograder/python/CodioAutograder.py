from CodioLogger import CodioLogger
from CodioLib import CodioLib
import argparse
import sys
import unittest
import traceback

class CodioAutograder():

    def main(self):

        #Parse Command Line Arguments
        args = self.parseCommandLineOptions

        #Initialize Libraries
        self.codiolib = CodioLib()

        #Parse tests
        tests = self.parseTests(args)

        #Initialise Logger
        outputfile = args.outputfile

        if args.pregrade:
            self.logger = CodioLogger(outputfile + ".pregrade.html", outputfile + ".pregradelog.txt")
        else:
            self.logger = CodioLogger(outputfile + ".autograde.html", outputfile + ".autogradelog.txt")

        #Print Log Headers
        self.logger.printHeaders()

        if args.unittest:
            tests = self.runPyUnitTests(tests)
        elif args.difftest:
            tests = self.runTextDiffTests(tests)
        else:
            print("UNREACHABLE: Unknown Test Option!", file=sys.stderr)
            sys.exit(1)

        if args.otherweight is not None:
            if args.otherweight > 0:
              tests.append(self.getOtherScore(args))

        pointspossible = 100
        if args.totalpointspossible is not None:
            if args.totalpointspossible < 0:
                print("Error: Total points possible {} cannot be negative".format(args.totalpointspossible))
                sys.exit(1)
            pointspossible = args.totalpointspossible

        scale = self.checkWeights(tests, pointspossible)

        finalScore = self.calculateFinalScore(tests, scale)

        self.logger.printSummary(tests, finalScore, scale, pointspossible)

        if args.pregrade:
            self.codiolib.partialPoints(finalScore, self.logger)
            print("Score: " + str(finalScore))
            print("Details in " + str(outputfile) + ".pregrade.html")
        else:
            self.codiolib.sendScore(finalScore, self.logger)
            print("Score: " + str(finalScore))
            print("Details in " + str(outputfile) + ".autograde.html")

        self.logger.close()

    @property
    def parseCommandLineOptions(self):
        """
        Parses command line arguments using argparse
        :return: parsed arguments
        """
        parser = argparse.ArgumentParser()

        #Unit Test or Diff Test
        group = parser.add_mutually_exclusive_group(required=True)
        group.add_argument("-u", "--unittest", help="Perform JUnit Tests", action="store_true")
        group.add_argument("-d", "--difftest", help="Perform Text Diff Tests", action="store_true")

        parser.add_argument("outputfile", help="Path Prefix for Output Files", type=str)

        parser.add_argument("-p", "--pregrade", help="Pregrade output only", action="store_true")

        parser.add_argument("-o", "--otherweight", help="The Weight Applied to Other Assignments", type=int)

        parser.add_argument("-s", "--totalpointspossible", help="The Total Points Possible for This Assignment", type=int)

        parser.add_argument("tests", help="List of test classes followed by weights", nargs='+', type=str)

        return parser.parse_args()

    def parseTests(self, args):
        if len(args.tests) % 2 != 0:
            print("Error! Must provide an even number of arguments for tests, both a class and a weight", file=sys.stderr)
            sys.exit(1)

        tests = []

        for i in range(0, len(args.tests), 2):
            test = {}

            try:
                test['classname'] = args.tests[i]
                module = __import__(test['classname'])
                test['classref'] = getattr(module, test['classname'])

                test['weight'] = int(args.tests[i+1])

                tests.append(test)
            except Exception as ex:
                print("Error parsing test classes and weights!", file=sys.stderr)
                print(ex, file=sys.stderr)

        return tests

    def getOtherScore(self, args):
        test = {}
        test['classname'] = "Other Assessments"
        test['classref'] = None
        test['weight'] = args.otherweight
        test['score'] = self.codiolib.getOtherScore(self.logger)
        return test

    def checkWeights(self, tests, pointspossible):
        sum = 0
        for test in tests:
            sum += test['weight']

        scale = 1.0

        if not sum == pointspossible:
            # print("Weights do not sum to 100!", file=sys.stderr)
            scale = pointspossible / sum
            self.logger.log("Final score will be multiplied by {} to find a final score out of {} points possible.".format(scale, pointspossible))

        return scale

    def runPyUnitTests(self, tests):

        for test in tests:

            self.logger.printClassHeader(test['classname'])

            try:
                testMod = unittest.TestLoader().loadTestsFromName(test['classname'])

                result = unittest.TextTestRunner(self.logger.logger).run(testMod)

                test['score'] = self.calculatePyUnitScore(result)

                self.logger.printPyUnitResults(result, test['score'], test['weight'])

            except Exception as ex:
                self.logger.log("Unable to instantiate and test {}!".format(test['classname']))
                self.logger.log(ex)

        return tests

    def calculatePyUnitScore(self, result):
        successes = result.testsRun - len(result.failures) - len(result.errors)
        score = successes / result.testsRun
        return score

    def runTextDiffTests(self, tests):

        for test in tests:

            self.logger.printClassHeader(test['classname'])

            try:
                instance = test['classref']()
                results = instance.runTests(self.logger)
                test['score'] = self.calculateDiffScore(results)
                self.logger.printCustomResults(results, test['score'], test['weight'])

            except Exception as ex:
                self.logger.log("Unable to instantiate and test {}!".format(test['classname']))
                self.logger.log(ex)
                #traceback.print_exc()

        return tests

    def calculateDiffScore(self, results):
        sum = 0.0

        for result in results:
            sum += result['score']

        return sum / len(results)


    def calculateFinalScore(self, tests, scale):
        sum = 0.0

        for test in tests:
            sum += test['score'] * test['weight'] * scale

        return int(round(sum))

if (__name__ == '__main__'):
    grader = CodioAutograder()
    grader.main()
